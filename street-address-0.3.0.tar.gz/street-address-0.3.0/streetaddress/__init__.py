# -*- coding: utf-8 -*-

from .streetaddress import StreetAddressFormatter
from .streetaddress import StreetAddressParser

__title__ = 'streetaddress'
__version__ = '0.1.1'
